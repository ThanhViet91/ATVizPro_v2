package com.androidmarket.scanqr
import android.os.StrictMode
import android.os.StrictMode.VmPolicy
import androidx.multidex.MultiDexApplication
import com.androidmarket.scanqr.dependency.settings
import com.androidmarket.scanqr.usecase.Logger
import com.onesignal.OneSignal
import io.reactivex.plugins.RxJavaPlugins
class App : MultiDexApplication() {
    override fun onCreate() {
        handleUnhandledRxJavaErrors()
        enableStrictModeIfNeeded()
        applyTheme()
        super.onCreate()
        // Enable verbose OneSignal logging to debug issues if needed.
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE)
        // OneSignal Initialization
        OneSignal.initWithContext(this)
        OneSignal.setAppId(resources.getString(R.string.onesignalId))
    }
    private fun applyTheme() {
        settings.reapplyTheme()
    }

    private fun handleUnhandledRxJavaErrors() {
        RxJavaPlugins.setErrorHandler { error ->
            Logger.log(error)
        }
    }

    private fun enableStrictModeIfNeeded() {
        if (true) {
            return
        }

        StrictMode.setThreadPolicy(
                StrictMode.ThreadPolicy.Builder()
                        .detectAll()
                        .penaltyLog()
                        .penaltyDialog()
                        .build()
        )

        StrictMode.setVmPolicy(
                VmPolicy.Builder()
                        .detectAll()
                        .penaltyLog()
                        .penaltyDropBox()
                        .build()
        )
    }
}
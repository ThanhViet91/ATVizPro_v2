package com.androidmarket.scanqr.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.androidmarket.scanqr.R;
import com.applovin.mediation.MaxAd;
import com.applovin.mediation.MaxAdListener;
import com.applovin.mediation.MaxAdViewAdListener;
import com.applovin.mediation.MaxError;
import com.applovin.mediation.ads.MaxAdView;
import com.applovin.mediation.ads.MaxInterstitialAd;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkConfiguration;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity implements MaxAdListener {
    boolean doubleBackToExitPressedOnce = false;
    private MaxAdView adView;
    private AdView adViewAdmob;
    private InterstitialAd mInterstitialAdAdmob;
    public static boolean value;

    LinearLayout layout;
    private MaxInterstitialAd interstitialAd;
    private int retryAttempt;
    private int startScreen;

    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
        //Native Ad
        layout = findViewById(R.id.applovinbanner);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);


        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("isloadMAX");


        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                value = dataSnapshot.getValue(Boolean.class);
                //value = value;

                if (value) {
                    //MAX SDK
                    AppLovinSdk.getInstance(MainActivity.this).setMediationProvider("max");
                    AppLovinSdk.initializeSdk(MainActivity.this, new AppLovinSdk.SdkInitializationListener() {
                        @Override
                        public void onSdkInitialized(final AppLovinSdkConfiguration configuration) {
                            createBannerAd();
                            createInterstitialAd();
                        }
                    });
                }
                else {
                    //Admob
                    MobileAds.initialize(MainActivity.this, new OnInitializationCompleteListener() {
                        @Override
                        public void onInitializationComplete(InitializationStatus initializationStatus) {
                            createBannerAdmob();
                            createInterstitialAdmob();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
            }
        });
    }


    @Override
    public void onBackPressed() {
        ShowBackStuff();
    }

    public void ShowBackStuff() {

        if (doubleBackToExitPressedOnce) {
            finish();
            return;
        }

        doubleBackToExitPressedOnce = true;
        RelativeLayout exitLayout = findViewById(R.id.exitLayout);
        exitLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                exitLayout.setVisibility(View.INVISIBLE);
            }
        });
        exitLayout.setVisibility(View.VISIBLE);
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);


    }

    public void Disppear(View view) {
        RelativeLayout exitLayout = findViewById(R.id.exitLayout);
        exitLayout.setVisibility(View.INVISIBLE);
    }


    public void StartScan(View view) {
        startActivity(new Intent(MainActivity.this, ScanActivity.class));

       /* if (value) {
            if (interstitialAd.isReady()) {
                interstitialAd.showAd();
                startScreen = 1;
            } else {
                startActivity(new Intent(MainActivity.this, ScanActivity.class));
            }
        } else {
            if (mInterstitialAdAdmob != null) {
                mInterstitialAdAdmob.show(MainActivity.this);
                startScreen = 1;
            } else {
                startActivity(new Intent(MainActivity.this, ScanActivity.class));
            }
        }*/
    }


    public void StartCreation(View view) {

        if (value) {
            if (interstitialAd.isReady()) {
                interstitialAd.showAd();
                startScreen = 2;
            } else {
                startActivity(new Intent(MainActivity.this, CreateActivity.class));
            }
        } else {
            if (mInterstitialAdAdmob != null) {
                mInterstitialAdAdmob.show(MainActivity.this);
                startScreen = 2;
            } else {
                startActivity(new Intent(MainActivity.this, CreateActivity.class));
            }
        }
    }

    public void ShowHistory(View view) {
        if (value) {
            if (interstitialAd.isReady()) {
                interstitialAd.showAd();
                startScreen = 3;
            } else {
                startActivity(new Intent(MainActivity.this, HistoryActivity.class));
            }

        } else {
            startActivity(new Intent(MainActivity.this, HistoryActivity.class));

            /*if (mInterstitialAdAdmob != null) {
                mInterstitialAdAdmob.show(MainActivity.this);
                startScreen = 3;
            } else {
                startActivity(new Intent(MainActivity.this, HistoryActivity.class));
            }*/
        }
    }


    public void StartSetting(View view) {
        if (value) {
            if (interstitialAd.isReady()) {
                interstitialAd.showAd();
                startScreen = 4;
            } else {
                startActivity(new Intent(MainActivity.this, SettingActivity.class));

            }

        } else {
            if (mInterstitialAdAdmob != null) {
                mInterstitialAdAdmob.show(MainActivity.this);
                startScreen = 4;
            } else {
                startActivity(new Intent(MainActivity.this, SettingActivity.class));
            }
        }
    }


    public void Share(View view) {
        try {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.setType("text/plain");
            intent.putExtra("android.intent.extra.SUBJECT", "My application name");
            intent.putExtra("android.intent.extra.TEXT", "\nLet me recommend you this application\n\n" + "https://play.google.com/store/apps/details?id=" + getPackageName());
            startActivity(Intent.createChooser(intent, "Choose one"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void MoreApps(View view) {
        String url = "https://play.google.com/store/apps/developer?id=yourDeveloperId";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        startActivity(i);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    void createBannerAd() {
        adView = new MaxAdView(getApplicationContext().getString(R.string.applovin_banner), this);
        adView.setListener(new MaxAdViewAdListener() {
            @Override
            public void onAdExpanded(MaxAd ad) {

            }

            @Override
            public void onAdCollapsed(MaxAd ad) {

            }

            @Override
            public void onAdLoaded(MaxAd ad) {
            }

            @Override
            public void onAdDisplayed(MaxAd ad) {
            }

            @Override
            public void onAdHidden(MaxAd ad) {

            }

            @Override
            public void onAdClicked(MaxAd ad) {

            }

            @Override
            public void onAdLoadFailed(String adUnitId, MaxError error) {

            }

            @Override
            public void onAdDisplayFailed(MaxAd ad, MaxError error) {

            }
        });
        // Stretch to the width of the screen for banners to be fully functional
        int width = ViewGroup.LayoutParams.MATCH_PARENT;
        // Banner height on phones and tablets is 50 and 90, respectively
        int heightPx = getResources().getDimensionPixelSize(R.dimen.banner_height);
        adView.setLayoutParams(new FrameLayout.LayoutParams(width, heightPx, Gravity.BOTTOM));
        // Set background or background color for banners to be fully functional
        adView.setBackgroundColor(Color.WHITE);
        ViewGroup rootView = findViewById(android.R.id.content);
        layout.removeAllViews();
        layout.addView(adView);
        // Load the ad
        adView.loadAd();
    }

    void createInterstitialAd() {
        interstitialAd = new MaxInterstitialAd(getResources().getString(R.string.applovin_intersitial), MainActivity.this);
        interstitialAd.setListener(MainActivity.this);
        // Load the first ad
        interstitialAd.loadAd();
    }

    // MAX Ad Listener
    @Override
    public void onAdLoaded(final MaxAd maxAd) {
        // Interstitial ad is ready to be shown. interstitialAd.isReady() will now return 'true'

        // Reset retry attempt
        retryAttempt = 0;
    }

    @Override
    public void onAdLoadFailed(final String adUnitId, final MaxError error) {
        // Interstitial ad failed to load
        // We recommend retrying with exponentially higher delays up to a maximum delay (in this case 64 seconds)

        retryAttempt++;
        long delayMillis = TimeUnit.SECONDS.toMillis((long) Math.pow(2, Math.min(6, retryAttempt)));

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                interstitialAd.loadAd();
            }
        }, delayMillis);
    }

    @Override
    public void onAdDisplayFailed(final MaxAd maxAd, final MaxError error) {
        // Interstitial ad failed to display. We recommend loading the next ad
        interstitialAd.loadAd();
    }

    @Override
    public void onAdDisplayed(final MaxAd maxAd) {
    }

    @Override
    public void onAdClicked(final MaxAd maxAd) {
    }

    @Override
    public void onAdHidden(final MaxAd maxAd) {
        if (startScreen == 1) {
            startActivity(new Intent(MainActivity.this, ScanActivity.class));
        }
        if (startScreen == 2) {
            startActivity(new Intent(MainActivity.this, CreateActivity.class));
        }
        if (startScreen == 3) {
            startActivity(new Intent(MainActivity.this, HistoryActivity.class));
        }
        if (startScreen == 4) {
            startActivity(new Intent(MainActivity.this, SettingActivity.class));
        }
        // Interstitial ad is hidden. Pre-load the next ad
        interstitialAd.loadAd();
    }

    void createBannerAdmob() {
        adViewAdmob = new AdView(this);
        adViewAdmob.setAdSize(AdSize.BANNER);
        adViewAdmob.setAdUnitId(getResources().getString(R.string.admob_banner));
        AdRequest adRequest = new AdRequest.Builder().build();
        adViewAdmob.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                layout.removeAllViews();
                layout.addView(adViewAdmob);
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
            }

            @Override
            public void onAdOpened() {
            }

            @Override
            public void onAdClicked() {
            }

            @Override
            public void onAdClosed() {
            }
        });
        adViewAdmob.loadAd(adRequest);
    }

    void createInterstitialAdmob() {

        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this, getResources().getString(R.string.admob_intersitial), adRequest,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                        mInterstitialAdAdmob = interstitialAd;
                        mInterstitialAdAdmob.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {

                                createInterstitialAdmob();

                                Log.d("TAG", "The ad was dismissed.");
                                if (startScreen == 1) {
                                    startActivity(new Intent(MainActivity.this, ScanActivity.class));
                                }
                                if (startScreen == 2) {
                                    startActivity(new Intent(MainActivity.this, CreateActivity.class));
                                }
                                if (startScreen == 3) {
                                    startActivity(new Intent(MainActivity.this, HistoryActivity.class));
                                }
                                if (startScreen == 4) {
                                    startActivity(new Intent(MainActivity.this, SettingActivity.class));
                                }
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(AdError adError) {
                                Log.d("TAG", "The ad failed to show.");
                            }

                            @Override
                            public void onAdShowedFullScreenContent() {
                                mInterstitialAdAdmob = null;
                                Log.d("TAG", "The ad was shown.");
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        mInterstitialAdAdmob = null;
                        createInterstitialAdmob();
                    }
                });
    }
}
package com.androidmarket.scanqr.usecase

import com.androidmarket.scanqr.BuildConfig

object Logger {
    var isEnabled = BuildConfig.ERROR_REPORTS_ENABLED_BY_DEFAULT

    fun log(error: Throwable) {
        if (isEnabled) {
            //remove
        }
    }
}
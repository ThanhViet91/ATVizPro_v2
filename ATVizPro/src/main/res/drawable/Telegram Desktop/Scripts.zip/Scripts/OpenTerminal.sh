#!/bin/bash
# Project Name:  $XcodeProject
# Project Dir:   $XcodeProjectPath
# Workspace Dir: $XcodeWorkspacePath

open -a Terminal "$(dirname $XcodeProjectPath)"
